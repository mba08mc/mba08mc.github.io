AroundMe Revival (aroundmed) 1.3

Needs the iProjects-patched AroundMe 4.2.5 (it talks to am-ajax.invalid /
am-geo.invalid instead of Google's and GeoNames' real servers, and skips a
dead DNS lookup for Apple Stores).

aroundmed listens on 127.0.0.1 only:
  port 80      search, place pages, change location, weather, Wikipedia, settings
  port 27040   Apple Retail Stores (MongoDB protocol)
and these lines were added to /etc/hosts (removed again on uninstall):
  127.0.0.1 am-ajax.invalid
  127.0.0.1 am-geo.invalid
  127.0.0.1 setting.tweakersoft.com
  127.0.0.1 aroundme.meteogroup.de
  127.0.0.1 m.aroundme.info


Data: Geoapify (OpenStreetMap), Nominatim, Open-Meteo, Wikipedia - over TLS 1.2,
certificates checked against /usr/share/aroundmed/cacert.pem.

Geoapify key: a shared default key is built in. To use your own (free at
geoapify.com, 3000 requests/day), set it in the iProjects app (AroundMe section),
or add the string "AroundMe.GeoapifyKey" to
/var/mobile/Library/Preferences/com.iprojects.settings.plist.

Problems are logged to syslog (tag "aroundmed"). To see everything:
  touch /tmp/aroundmed-debug      then use AroundMe, then:  cat /tmp/aroundmed.log
  rm /tmp/aroundmed-debug /tmp/aroundmed.log     when you're done
Cache: /var/tmp/aroundmed (safe to delete).
