# Claude Classic — Claude for old Macs, old Windows, the original iPhone and BlackBerry

Native Claude clients for systems whose own networking is too old for api.anthropic.com. Every client
shares one portable C core (`core/`): its own TLS 1.2 stack (Mbed TLS), the Messages API streaming,
Markdown rendering, chat storage and the Claude.ai export importer. Each platform is a thin native wrapper.

| Client | Runs on | Folder | How to build |
|---|---|---|---|
| **Claude** (main) | Mac OS X 10.4 – 10.6, Intel (+ PowerPC 10.4/10.5) | `mac/` | `./build.sh` (Xcode 3.1/3.2) |
| **Claude Legacy** | Mac OS X 10.2 Jaguar / 10.3 Panther, PowerPC | `maclegacy/` | `./maclegacy/build.sh` |
| **ClaudeXP.exe** | Windows 2000 / XP / Vista / 7 | `win/` | prebuilt in `windows/` |
| **Claude9x.exe** | Windows 98 / 98 SE / ME (95 with IE5) | `win/` | prebuilt in `windows/` |
| **Claude for iPhone** | iPhone OS 2.x (armv6) | `iphone/` | `./iphone/build.sh` (Xcode 3.1.2 iPhone SDK) |
| **Claude for BlackBerry** | BlackBerry OS 6 (Torch 9800, 360x480; runs on OS 5/7 too) | `blackberry/` | `blackberry\build.bat` (JDE 6.0) |

BlackBerry can't run C, so it has a Java port of the core (`blackberry/src/.../core`, `.../tls`), with the same API
logic, storage format and system prompt.

All clients store chats in the same JSON format, so a chat exported/imported on one works on another.
API usage needs a key from <https://console.anthropic.com/settings/keys> (pay-as-you-go, separate from a Claude.ai plan).

---

# Mac OS X 10.4 – 10.6 (main client)

Dark, iLife-style Cocoa UI.

## Build (one command)

You need Xcode 3.1.x or 3.2.x **with the Mac OS X 10.4 SDK** (in the Xcode installer it's under *Custom Install → Mac OS X 10.4 Support*). Check you have `/Developer/SDKs/MacOSX10.4u.sdk`.

```sh
cd ClaudeClassic
./build.sh
open build/Claude.app
```

* First build compiles ~110 files (Mbed TLS is most of it). On a Core 2 Duo that's a few minutes; rebuilds are incremental.
* It tries Intel **and** PowerPC. If PowerPC fails it just warns and carries on with Intel. Skip it with `ARCHS=i386 ./build.sh`.
* Xcode not in `/Developer`? `DEVELOPER_DIR=/Xcode3.1.2 ./build.sh`
* `./build.sh clean` starts over.

If anything fails, send me the **first** error lines from the output.

## First run

1. The app opens Preferences → *API & Connection*. Paste an API key from <https://console.anthropic.com/settings/keys> (it starts with `sk-ant-`).
   API usage is pay-as-you-go and separate from a Claude.ai Pro plan.
2. Click **Test Connection**. This also downloads the live model list, so the model menu shows exactly what your key can use.

## Features

* Streaming replies, rendered as Markdown with syntax-highlighted code blocks (Copy / Save / Preview for HTML & SVG)
* Every model your key has, with **effort** levels (Low → Max) where the model supports them
* **Extended thinking** with a collapsible "Thought process"
* **Web search** with source lists and inline citation links
* **Attachments**: drag, paste or ⇧⌘A for images, PDFs, text/code files, RTF/Word documents
* **Projects**: custom instructions plus knowledge files (text, code, PDF text, Word/RTF) shared by every chat in the project
* **Styles** (Normal / Concise / Explanatory / Formal) and "What should Claude know about you?"
* Edit a sent message, Retry, Continue (when a reply hits the length limit), Stop (⌘.)
* Sidebar with Starred / Recents, search, rename, star, move to project, delete, export to Markdown
* Auto-generated chat titles
* **Import your Claude.ai history**: on claude.ai go to Settings → Privacy → Export data, unzip the file you're emailed, then choose File → Import from Claude.ai. Imported chats can be continued.

Keyboard: Return sends, Shift/Option-Return adds a new line, ⌘N new chat, ⌘R regenerate, ⌃⌘S toggle sidebar, ⌥⌘F search chats, ⌘+/⌘- text size.

## Not possible over the API

Claude.ai memory, connectors, Claude Code/Cowork, voice, and live artifacts. HTML/SVG code can be previewed in your browser instead.

## Troubleshooting

* **"Certificate check failed … starts in the future"**: your Mac's clock is wrong (common with a flat PRAM battery). Fix the date and time.
* **Behind a proxy / want to go through your retro-gateway**: Preferences → *API & Connection* → HTTP proxy (uses CONNECT, so TLS is still end-to-end). Or set *API server* to an `http://` relay you control.
* **Certificates expire over the years**: replace `Claude.app/Contents/Resources/cacert.pem` with a current Mozilla bundle (e.g. from <https://curl.se/ca/cacert.pem>), or add one under *Extra certificates*.

## Your data

Everything is stored locally as JSON in `~/Library/Application Support/Claude for Mac OS X/`. Image thumbnails are cached in `~/Library/Caches/Claude for Mac OS X/`. The API key is in your Keychain.

---

# Mac OS X 10.2 / 10.3 (PowerPC) — Claude Legacy

A simpler Cocoa client (chat list, streaming replies rendered as rich text, model menu, web search and
thinking switches, file attachments, Claude.ai import, Keychain-stored key). Uses only 10.2 APIs.

* On a PowerPC Mac with 10.3 + Xcode 1.5: `./maclegacy/build.sh`
* On 10.2 with the December 2002 dev tools: `CC=gcc-3.3 ./maclegacy/build.sh`
* On your Snow Leopard Xcode with the 10.3.9 SDK (app then needs 10.3.9+):
  `SDK=/Developer/SDKs/MacOSX10.3.9.sdk CC=gcc-4.0 ./maclegacy/build.sh`

Output: `build/legacy/Claude Legacy.app`. It shares its chat folder with the main Mac client.

# Windows

`windows/ClaudeXP.exe` and `windows/Claude9x.exe` are ready to run - keep `cacert.pem` in the same folder.
They were cross-compiled with clang/lld against Windows 98's msvcrt.dll with no MinGW runtime, so the
9x build only imports functions that exist on Windows 98. Chats live in `%APPDATA%\Claude Classic`
(XP/Vista) or a `Data` folder next to the program (98/ME). On XP/Vista the API key is protected with DPAPI.

Rebuilding (on Linux/macOS with clang, lld, llvm-rc, llvm-dlltool): `win/setup_toolchain.sh`, then `win/build_win.sh`.

Keys: Enter sends, Shift+Enter new line, Esc stops, Ctrl+N new chat, Ctrl+R retry, Ctrl+E edit last message,
Ctrl+Shift+C copy last reply, Ctrl+, settings. Right-click a chat to rename/export/delete. Drag files onto the window to attach.

# iPhone OS 2

`./iphone/build.sh` with Xcode 3.1.2's iPhone SDK. Set `CODESIGN_IDENTITY` to sign with your developer
certificate, or have `ldid` installed for a jailbroken device. Chat list, streaming chat view (UIWebView with
the same renderer as the Mac), photo attachments, model/search/thinking options, settings with Keychain-stored key.
iPhone OS 2 has no copy & paste, so copy buttons are hidden there.

---

# BlackBerry OS 6

A native BlackBerry Java app (a RIM `UiApplication` with custom-painted screens), not a MIDlet.

* **Its own TLS 1.2** in Java 1.3 (`tls/`): X25519 / P-256 / P-384 ECDHE, AES-128-GCM, RSA and ECDSA
  certificate checks against the Mozilla roots (`res/roots.bin`, rebuilt with `tools/make_bb_roots.py`).
  OS 6's own TLS is too old for api.anthropic.com, and RIM's crypto APIs need signing keys that RIM no
  longer issues. The app uses **no signed APIs**, so it installs and runs unsigned.
* Chat list, streaming replies with Markdown (headings, lists, task lists, quotes, code blocks, tables as
  cards), thinking and web-search rows, citations and sources, a composer with model / thinking / search chips,
  photo / PDF / text attachments from the media card, retry, edit last message, rename / delete, auto titles,
  settings (style, preferences, effort, max length, text size, connection type and APN).
* Trackpad, keyboard and touch all work. Enter sends (Shift+Enter for a new line), Esc stops a reply,
  and the menu has every action. Copying uses a read-only text screen, because the clipboard API needs signing.

**Build** on Windows with the BlackBerry JDE 6.0 and JDK 6: `blackberry\build.bat` → `build\Claude.cod`.
To install, use `JavaLoader -usb load Claude.cod`, Desktop Manager with `Claude.alx`, or the BlackBerry Java
Plug-in for Eclipse (import `src/` and `res/`; the app type is BlackBerry Application). On a Mac or Linux
machine with `rapc.jar`, use `blackberry/build.sh <jde folder>`.

**First run:** the first time the app connects and saves, allow Connections and Files when asked (or set them
in Options → Applications → Claude → Edit Permissions). Then paste your API key in Settings and choose
*Test Key & Load Models*. Connection *Automatic* tries Wi-Fi first, then the mobile network (direct TCP;
set the APN if your carrier needs one). Chats are saved to `/store/home/user/ClaudeClassic/` in the shared format.

**Optional relay:** `tools/bb_relay.py` on a computer forwards plain HTTP to the API. It's only useful if the
on-device TLS handshake (a few seconds on a 624 MHz Torch) bothers you on home Wi-Fi.

**No RIM tools on hand?** `blackberry/tools/check_bb.sh` compiles everything against CLDC 1.1 + BlackBerry API
signature stubs and rejects post-Java-1.3 syntax. `blackberry/test/run_sim.sh` runs the real app on a desktop
stand-in for the RIM UI classes and renders Torch-sized screenshots (see `blackberry/screenshots/`).

---

# Mail on iPhone OS 2 — MailTLS

`mail/` is a small add-on for jailbroken iPhone OS 2: it lets the built-in Mail app reach Gmail, iCloud
and Yahoo again. Mail talks plain text to 127.0.0.1 and `mailtls` forwards each connection to the real
server over TLS 1.2 (Mbed TLS, certificate checked). launchd keeps one small listener per server running;
they sit idle in accept() until Mail connects, so they cost no battery. (launchd's on-demand inetd sockets
didn't work on iPhone OS 2.1, so 1.1 switched to listeners.) `touch /tmp/mailtls-debug` turns on a
per-connection log in `/tmp/mailtls.log` with passwords blanked out.

`./mail/build.sh` (same Xcode 3.1.x + ldid setup as the iPhone app) builds a Cydia package,
`build/mailtls/com.claudeclassic.mailtls_1.0_iphoneos-arm.deb`. Install it from your repo (or `dpkg -i`),
then add each account as *Other* with SSL off: Gmail 127.0.0.1 ports 1143 / 1465, iCloud 2143 / 2587,
Yahoo 3143 / 3465, AOL 4143 / 4465, using an app password. (Outlook.com/Hotmail can't work: Microsoft requires OAuth.)

---

**Mac OS X 10.4–10.6 too:** `mail/build_mac.sh` builds the same relay (Intel + PowerPC) into
`build/MailTLS-Mac.zip`: double-click *Install MailTLS.command*, then point Mail at 127.0.0.1 with the same
ports (setup steps in its README.txt). It fixes both Mail's old TLS and its out-of-date certificate list.

## Source layout

```
core/      portable C shared by every client
  cc_http     HTTP/1.1 client + Mbed TLS, proxy CONNECT, streaming
  cc_stream   SSE parser + Messages API stream accumulator
  cc_api      request building (thinking/effort/search/caching), model list parsing
  cc_md, cc_hl  Markdown → HTML, syntax highlighting
  cc_render   message → HTML (thinking, search results, citations, attachments)
  cc_import   claude.ai export importer
  cc_json, cc_buf  JSON + buffers
  cc_store    chat storage + settings (Windows, Legacy Mac, iPhone)
  cc_prompt   system prompt
  cc_rtf      HTML -> RTF for RichEdit (Windows) and NSTextView (Legacy Mac)
mac/       Objective-C 1.0 Cocoa front-end for 10.4-10.6 (no nibs, no Xcode project needed)
maclegacy/ Cocoa front-end for 10.2/10.3
win/       Win32 front-end (Unicode XP build + ANSI 9x build), Winsock 1.1 network layer, tiny CRT shims
iphone/    UIKit front-end for iPhone OS 2
mail/      MailTLS: TLS 1.2 relay so Mail on iPhone OS 2 and Mac OS X 10.4-10.6 works with today's servers
blackberry/ BlackBerry OS 6 app: Java port of the core + TLS 1.2 (src/), RIM UI, rapc build, desktop simulator (sim/)
vendor/    Mbed TLS 2.28 (Apache-2.0); two small patches marked "CC PATCH" for Windows 9x
tests/     Linux test suite for core/ (tests/build_linux.sh)
tools/     check_mac.sh (API check against the 10.4 SDK headers), make_art.py (icon)
```
