MailTLS for Mac OS X 10.4 - 10.6

Mail on Tiger, Leopard and Snow Leopard only speaks old TLS and trusts an out-of-date
list of certificates, so Gmail, iCloud, Yahoo and AOL refuse it or throw certificate
warnings. MailTLS runs small relays on 127.0.0.1: Mail talks to them in plain text
(it never leaves your Mac) and they talk TLS 1.2 to the real servers, checking each
server's certificate against an up-to-date list.

INSTALL: double-click "Install MailTLS.command" and enter your password.
REMOVE:  double-click "Uninstall MailTLS.command".

SETTING UP AN ACCOUNT (Snow Leopard wording; Tiger/Leopard are similar)

1. Mail > Preferences > Accounts > +. Name, full address, password (see APP PASSWORDS).
   Uncheck "Automatically set up account" if it's offered, then Continue.
2. Account type IMAP. Incoming mail server: 127.0.0.1. User name: your full address.
   Mail will say it can't connect (it's trying the standard port) - choose Continue.
3. Outgoing mail server: 127.0.0.1, "Use Authentication" on, full address + password.
   Again Continue past the connection warning, then Create.
4. Mail > Preferences > Accounts > (the account) > Advanced:
   Port = the incoming port below, "Use SSL" OFF.
5. Account Information > Outgoing Mail Server > Edit SMTP Server List > Advanced:
   "Use custom port" = the outgoing port below, "Use Secure Sockets Layer" OFF,
   Authentication: Password.
6. Quit and reopen Mail.

            incoming            outgoing
  Gmail     127.0.0.1 : 1143    127.0.0.1 : 1465
  iCloud    127.0.0.1 : 2143    127.0.0.1 : 2587
  Yahoo     127.0.0.1 : 3143    127.0.0.1 : 3465
  AOL       127.0.0.1 : 4143    127.0.0.1 : 4465

APP PASSWORDS: Gmail, iCloud, Yahoo and AOL all need an app password for Mail, not
your normal one. Gmail and Yahoo only offer them with 2-step verification turned on.
Outlook.com / Hotmail can't work: Microsoft only allows OAuth sign-in for IMAP/SMTP.

ALREADY HAVE THE ACCOUNT? Just change its incoming and outgoing servers to 127.0.0.1
and the ports/SSL as in steps 4-5. Your mail stays where it is.

TROUBLESHOOTING
  Test a relay in Terminal:   telnet 127.0.0.1 1143   (Gmail should answer "* OK Gimap ready";
                              quit with Ctrl-] then "quit")
  Detailed log:   touch /tmp/mailtls-debug, try again in Mail, then: cat /tmp/mailtls.log
                  (passwords are blanked out)   Turn off: rm /tmp/mailtls-debug /tmp/mailtls.log
