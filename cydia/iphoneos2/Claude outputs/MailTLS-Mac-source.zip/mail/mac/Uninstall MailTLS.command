#!/bin/sh
# Removes MailTLS (the relays, their launchd jobs and files). Mail accounts are left alone.
if [ "$(id -u)" != "0" ]; then
    echo "Removing MailTLS needs your administrator password."
    exec sudo /bin/sh "$0" "$@"
fi
for f in /Library/LaunchDaemons/com.claudeclassic.mailtls.*.plist; do
    [ -f "$f" ] || continue
    launchctl unload -w "$f" 2>/dev/null
    rm -f "$f"
done
rm -f /usr/local/libexec/mailtls
rm -rf /usr/local/share/mailtls
echo "MailTLS removed. Change any Mail accounts that used 127.0.0.1 back to their real servers."
