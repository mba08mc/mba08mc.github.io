#!/bin/sh
# Installs MailTLS on Mac OS X 10.4 - 10.6. Double-click it; it asks for your password once.
# Files: /usr/local/libexec/mailtls, /usr/local/share/mailtls/, /Library/LaunchDaemons/com.claudeclassic.mailtls.*.plist

cd "$(dirname "$0")"
DIR=$(pwd)
ROOT=${MAILTLS_TEST_ROOT:-}        # (for testing only: install into another folder, skip launchctl)

if [ ! -f "$DIR/mailtls" ] || [ ! -f "$DIR/cacert.pem" ]; then
    echo "mailtls and cacert.pem must be in the same folder as this script."; exit 1
fi
if [ -z "$ROOT" ] && [ "$(id -u)" != "0" ]; then
    echo "MailTLS needs your administrator password to install."
    exec sudo /bin/sh "$0" "$@"
fi

LD=$ROOT/Library/LaunchDaemons
PREFIX=com.claudeclassic.mailtls

# stop an older copy first
for f in "$LD"/$PREFIX.*.plist; do
    [ -f "$f" ] || continue
    [ -z "$ROOT" ] && launchctl unload "$f" 2>/dev/null
    rm -f "$f"
done

mkdir -p "$ROOT/usr/local/libexec" "$ROOT/usr/local/share/mailtls" "$LD"
cp "$DIR/mailtls" "$ROOT/usr/local/libexec/mailtls"
cp "$DIR/cacert.pem" "$ROOT/usr/local/share/mailtls/cacert.pem"
[ -f "$DIR/README.txt" ] && cp "$DIR/README.txt" "$ROOT/usr/local/share/mailtls/README.txt"
chmod 755 "$ROOT/usr/local/libexec/mailtls"
chmod 644 "$ROOT/usr/local/share/mailtls/"*
[ -z "$ROOT" ] && chown -R root:wheel "$ROOT/usr/local/libexec/mailtls" "$ROOT/usr/local/share/mailtls"

# name  local-port  server  server-port  [-s for STARTTLS]
SERVICES="gmail-imap 1143 imap.gmail.com 993
gmail-smtp 1465 smtp.gmail.com 465
icloud-imap 2143 imap.mail.me.com 993
icloud-smtp 2587 smtp.mail.me.com 587 -s
yahoo-imap 3143 imap.mail.yahoo.com 993
yahoo-smtp 3465 smtp.mail.yahoo.com 465
aol-imap 4143 imap.aol.com 993
aol-smtp 4465 smtp.aol.com 465"

echo "$SERVICES" | while read name lport host port flag; do
    plist="$LD/$PREFIX.$name.plist"
    extra=""
    [ -n "$flag" ] && extra="		<string>$flag</string>
"
    cat > "$plist" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>Label</key>
	<string>$PREFIX.$name</string>
	<key>ProgramArguments</key>
	<array>
		<string>/usr/local/libexec/mailtls</string>
		<string>-c</string>
		<string>/usr/local/share/mailtls/cacert.pem</string>
		<string>-l</string>
		<string>$lport</string>
${extra}		<string>$host</string>
		<string>$port</string>
	</array>
	<key>UserName</key>
	<string>nobody</string>
	<key>RunAtLoad</key>
	<true/>
	<key>OnDemand</key>
	<false/>
	<key>KeepAlive</key>
	<true/>
	<key>ThrottleInterval</key>
	<integer>10</integer>
</dict>
</plist>
EOF
    chmod 644 "$plist"
    [ -z "$ROOT" ] && chown root:wheel "$plist" && launchctl load -w "$plist"
done

if [ -z "$ROOT" ]; then
    sleep 2
    n=$(ps ax | grep -c '[m]ailtls -c')
    echo
    echo "MailTLS installed - $n of 8 relays running."
fi
cat <<'EOF'

Set up each account in Mail with SSL OFF and these servers (Mail > Preferences >
Accounts > Advanced for the incoming port; Edit SMTP Server List > Advanced >
"Use custom port" for the outgoing one). Use your full address and an app password.

            incoming            outgoing
  Gmail     127.0.0.1 : 1143    127.0.0.1 : 1465
  iCloud    127.0.0.1 : 2143    127.0.0.1 : 2587
  Yahoo     127.0.0.1 : 3143    127.0.0.1 : 3465
  AOL       127.0.0.1 : 4143    127.0.0.1 : 4465

More in /usr/local/share/mailtls/README.txt
EOF
