#!/bin/sh
#
# build_mac.sh - builds MailTLS for Mac OS X 10.4 Tiger -> 10.6 Snow Leopard (Intel + PowerPC).
#
#   mail/build_mac.sh          -> build/MailTLS-Mac.zip (and the folder build/MailTLS-Mac/)
#   ARCHS=i386 mail/build_mac.sh   Intel only
#
# Same tools as the main ./build.sh: Xcode 3.1/3.2 with gcc-4.0 and the 10.4u SDK (10.5 SDK works too).

set -e
cd "$(dirname "$0")/.."
[ -f core/cc_platform.c ] && [ -f mail/mailtls.c ] || { echo "error: run this from inside the ClaudeClassic folder"; exit 1; }

DEV=${DEVELOPER_DIR:-/Developer}
SDK=${SDK:-$DEV/SDKs/MacOSX10.4u.sdk}
[ -d "$SDK" ] || SDK=$DEV/SDKs/MacOSX10.5.sdk
[ -d "$SDK" ] || { echo "error: no 10.4u or 10.5 SDK in $DEV/SDKs. Set DEVELOPER_DIR to your Xcode folder."; exit 1; }
CC=${CC:-$DEV/usr/bin/gcc-4.0}
[ -x "$CC" ] || CC=/usr/bin/gcc-4.0
[ -x "$CC" ] || { echo "error: gcc-4.0 not found"; exit 1; }
LIPO=$DEV/usr/bin/lipo
[ -x "$LIPO" ] || LIPO=/usr/bin/lipo
ARCHS=${ARCHS:-"i386 ppc"}

echo "Compiler: $CC"
echo "SDK:      $SDK"
FLAGS="-isysroot $SDK -mmacosx-version-min=10.4 -Os -g0 -std=gnu99 -Icore -Ivendor/mbedtls/include -DMBEDTLS_USER_CONFIG_FILE=\"cc_mbedtls_user_config.h\""

OUT=build/MailTLS-Mac
BUILT=""
for ARCH in $ARCHS; do
    OBJ=build/obj-mailtls/$ARCH
    mkdir -p $OBJ
    echo "== $ARCH"
    if (
        # (set -e doesn't apply inside an if condition, hence the explicit || exit 1)
        for f in vendor/mbedtls/library/*.c core/cc_platform.c mail/mailtls.c; do
            o=$OBJ/$(basename $f .c).o
            if [ ! -f $o ] || [ $f -nt $o ] || [ core/cc_mbedtls_user_config.h -nt $o ]; then
                echo "  $(basename $f)"
                $CC -arch $ARCH $FLAGS -w -c $f -o $o || exit 1
            fi
        done
        $CC -arch $ARCH -isysroot $SDK -mmacosx-version-min=10.4 -o $OBJ/mailtls $OBJ/*.o || exit 1
    ); then
        BUILT="$BUILT $OBJ/mailtls"
    elif [ "$ARCH" = "ppc" ]; then
        echo "warning: PowerPC build failed - Intel only (ARCHS=i386 skips it)"
    else
        echo "error: build failed for $ARCH"; exit 1
    fi
done
[ -n "$BUILT" ] || { echo "error: nothing was built"; exit 1; }

rm -rf $OUT build/MailTLS-Mac.zip
mkdir -p $OUT
$LIPO -create $BUILT -output $OUT/mailtls
cp mac/Resources/cacert.pem $OUT/cacert.pem
cp "mail/mac/Install MailTLS.command" "mail/mac/Uninstall MailTLS.command" mail/mac/README.txt $OUT/
chmod 755 $OUT/mailtls "$OUT/Install MailTLS.command" "$OUT/Uninstall MailTLS.command"
(cd build && ditto -c -k --keepParent MailTLS-Mac MailTLS-Mac.zip)

echo
echo "Built $OUT ($($LIPO -info $OUT/mailtls | sed 's/.*: //'))"
echo "Install: double-click \"Install MailTLS.command\" in that folder (or copy MailTLS-Mac.zip to another Mac)."
