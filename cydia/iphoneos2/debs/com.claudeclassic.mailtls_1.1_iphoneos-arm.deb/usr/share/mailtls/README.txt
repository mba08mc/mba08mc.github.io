MailTLS 1.1

Set each account up in Settings > Mail > Add Account > Other, with SSL OFF and
these servers (Advanced > Server Port). User name is your full address; for
Gmail, Yahoo, AOL and iCloud the password must be an app password.

  Gmail    incoming 127.0.0.1 port 1143    outgoing 127.0.0.1 port 1465
  iCloud   incoming 127.0.0.1 port 2143    outgoing 127.0.0.1 port 2587
  Yahoo    incoming 127.0.0.1 port 3143    outgoing 127.0.0.1 port 3465
  AOL      incoming 127.0.0.1 port 4143    outgoing 127.0.0.1 port 4465

Outlook.com / Hotmail / Live can't work: Microsoft only accepts OAuth sign-in
for IMAP and SMTP now, which iPhone OS 2's Mail doesn't support.

Plain text only travels inside the phone; everything that leaves it is TLS 1.2
with the server's certificate checked against /usr/share/mailtls/cacert.pem.

Problems are logged to syslog (tag "mailtls"). If they mention certificate
dates, set the phone's date and time correctly.

Another provider: copy one of /Library/LaunchDaemons/com.claudeclassic.mailtls.*.plist, change the
Label, the port after -l and the server, then: launchctl load <file>
(add "-s" before the server for SMTP servers that only offer STARTTLS on 587).
